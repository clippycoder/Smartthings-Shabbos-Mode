"""Define consts for the pysmartthings package."""

__title__ = "pysmartthings"
__version__ = "0.7.7"
